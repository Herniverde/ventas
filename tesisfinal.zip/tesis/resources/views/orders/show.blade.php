@extends('layouts.app')

@section('title', 'Historico pedidos')

@section('body-class', 'product-page')


@section('content')

<div class="header header-filter" style="background-image: url({{url('/img/bg1.jpg')}}) ">
</div>

<div class="main main-raised">
    <div class="container">        

        <div class="section text-center">
            <h2 class="title">Historico pedidos</h2>
            
                @if (session('msg'))
                        <div class="alert alert-success">
                            {{ session('msg') }}
                        </div>
                @endif
                    
                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">
                                    <li class="active">                                   
                                      <a href="{{url('/home')}}" role="tab" data-toggle="tab">
                                            <i class="material-icons">dashboard</i>
                                            Historico de pedidos
                                        </a>
                                    </li>
                            
                           
                            
                        </ul>
                    </div>
                            
                    </div>
                    
                    <hr>
                        
                     
                            
                         <table class="table">
                        <thead>
                            <tr>
							
							
                                <th class="text-center">Número de pedido</th> 
                                <th class="text-center">Email</th>
								<th class="text-center">User_id</th> 								
                                <th class="text-center">telefono cliente</th> 	
								
                                <th class='text-center'>cantidad de productos pedidos</th>
                               <th class="text-center">lista de productos</th>
							   
                            </tr>
							
                        </thead>
						 <tbody>
                       @foreach ($users as $user)
					          
						<tr>
							<td>{{ $user->cart_id }}</td>
							<td>{{ $user->email }}</td>
							<td>{{ $user->user_id }}</td>
							<td>{{ $user->phone }}</td>
							<td>{{ $user->quantity}}</td>
							<td>{{ $user->name}}</td>
							</tr>
						@endforeach
						 </tbody>
						</table>
                    
						                                
                    
									<a href="{{ url('/') }}" >
                                          {{ csrf_field() }}                   
											<button class="btn btn-primary btn-around">
                                        Regresar
										</button>
                                  
								  </a>
                                                                    
                       
        </div>


       
    </div>

</div>

@include('includes.footer')
@endsection






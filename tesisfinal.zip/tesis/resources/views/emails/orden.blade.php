<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Nuevo Pedido</title>
</head>
<body>
	<h1>Pedido realizado</h1>
</body>
</html>
@extends('layouts.app')

@section('title', 'Ubicaciones')

@section('body-class', 'product-page')


@section('content')

<div class="header header-filter" style="background-image: url({{url('/img/bgMain1.jpg')}}) ">
</div>

<div class="main main-raised">
    <div class="container">

        <div class="section text-center">
            <h2 class="title">Ubicaciones</h2>
              <h3 class="title">Te esperamos en los siguientes puntos de atención: </h3>
                @if (session('msg'))
                        <div class="alert alert-success">
                            {{ session('msg') }}
                        </div>
                @endif

                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">




                        </ul>
                    </div>

                    </div>

                  



                         <table class="table">
                        <thead>
                            <tr>


                                <th class="text-center">Día</th>
                                <th class="text-center">Campus</th>
                                <th class='text-center'>Ubicación</th>

                            </tr>

                        </thead>
						 <tbody>


						<tr>

                <td>Lunes </td>
                <td>Queri, entrada principal, bloque 1</td>
                <td><a href="{{ url('https://goo.gl/maps/dFS98jZCr962') }}" target="_blank">
                                            {{ csrf_field() }}
                        <img src="/img/googlemaps.png" width=50 height=50>

                    </a> </td>
	</tr>	<tr>
            	<td>Martes </td>
							<td>UdlaPark, en el Patio Amazónico</td>
							<td><a href="{{ url('https://goo.gl/maps/hCp68W6ci3t') }}" target="_blank">
                                          {{ csrf_field() }}
										<img src="/img/googlemaps.png" width=50 height=50>

								  </a> </td>
							</tr>
							<tr>
							<td>Miércoles </td>
							<td>Granados, junto a La Corteza</td>
							<td><a href="{{ url('https://goo.gl/maps/iimZsy8n5kt') }}" target="_blank">
                                          {{ csrf_field() }}
										<img src="/img/googlemaps.png" width=50 height=50>

								  </a> </td>

							</tr>
								<tr>
							<td>Jueves</td>
							<td>Colón, patio central</td>
							<td><a href="{{ url('https://goo.gl/maps/UhPwY9FBbsC2') }}" target="_blank">
                                          {{ csrf_field() }}
											<img src="/img/googlemaps.png" width=50 height=50>

								  </a> </td>
							</tr>

            </tbody>

 </div>
         </table>
		 
		 
		   <div class="section text-center">
              <h3 class="title">Si necesitas mas informacion encuentranos en: </h3>
                @if (session('msg'))
                        <div class="alert alert-success">
                            {{ session('msg') }}
                        </div>
                @endif

                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">




                        </ul>
                    </div>

                    </div>

                   



                         <table class="table">
                        <thead>
                            <tr>


                                <th class="text-center">Campus</th>
                                <th class="text-center">Nombre</th>
                                <th class='text-center'>Ubicación</th>

                            </tr>

                        </thead>
						 <tbody>


						<tr>

                <td>Sede Queri</td>
                <td>Oficina de la Granja, frente al bloque 5</td>
                <td><a href="{{ url('https://goo.gl/maps/dFS98jZCr962') }}" target="_blank">
                                            {{ csrf_field() }}
                        <img src="/img/googlemaps.png" width=50 height=50>

                    </a> </td>
	</tr>	
			
            </tbody>

         </table>
		 
    </div>


</div>
</div>
</div>
</div>
@include('includes.footer')
@endsection

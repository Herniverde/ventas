



<?php $__env->startSection('content'); ?>



<?php $__env->startSection('title', 'Contactenos'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>
<!--<div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
</div>
-->
<div class="header header-filter" style="background-image: url(<?php echo e(url('/img/bg1.jpg')); ?>) ">
</div>

<div class="main main-raised">
    <div class="container">        

        <div class="section text-center">
		
<div class="container m-auto">
    <div class="row justify-content-center">
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 text-center">
            <h1>Contacto</h1>
            <?php if(isset($message)): ?>
            <div class="alert alert-success">
              <?php echo e($message); ?>

            </div>
            <?php endif; ?>
          <form class="<?php echo e($errors->any() ? '' :  'needs-validation'); ?>" id="needs-validation" action="/contact" method="post" novalidate>
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="name">Nombre</label>
                  <?php if($errors->any()): ?>
                    <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid':'is-valid'); ?>" id="name" placeholder="Nombres" value="<?php echo e(old('name')); ?>" required>
                  <?php else: ?>
                   <input type="text" name="name" class="form-control" id="name" placeholder="Nombres" value="<?php echo e(old('name')); ?>" required>
                  <?php endif; ?>
                  <div class="invalid-feedback">
                    <?php echo e($errors->has('name') ?  $errors->first('name') : 'Inserta tu nombre'); ?>

                  </div>
               
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label for="email">Email</label>
                  <?php if($errors->any()): ?>
                    <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid':'is-valid'); ?>" id="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                  <?php else: ?>
                    <input type="email" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                  <?php endif; ?>
                  <div class="invalid-feedback">
                    <?php echo e($errors->has('email') ?  $errors->first('email') : 'Inserta un email válido'); ?>

                  </div>
                 
                </div>
              </div>

              <div class="col-lg-12">
                <div class="form-group">
                <label for="message">Mensaje</label>
                <?php if($errors->any()): ?>
                  <textarea type="text" name="message" class="form-control <?php echo e($errors->has('message') ? 'is-invalid':'is-valid'); ?>" id="message" placeholder="Mensaje" rows="5" required><?php echo e(old('message')); ?></textarea>
                <?php else: ?>
                  <textarea type="text" name="message" class="form-control" id="message" placeholder="Mensaje" rows="5" required><?php echo e(old('message')); ?></textarea>
                <?php endif; ?>
                <div class="invalid-feedback">
                  <?php echo e($errors->has('message') ?  $errors->first('message') : 'Inserta tu mensaje'); ?>

                </div>
                
                </div>
              </div>
            </div>
            <div class="col-lg-2 send text-center text-lg-center">
              
			<button class="btn btn-primary btn-around" type="submit"><i class="material-icons">done</i><?php echo e(('Enviar')); ?></button></a>
			  
            </div>
			 <a href="<?php echo e(url('/welcome')); ?>" >
                        <?php echo e(csrf_field()); ?>                   
                        <button class="btn btn-primary btn-around">
                            <i class="material-icons">find_in_page</i> Regresar a la pagina principal
                        </button>
						</a>
          </form>
        </div>
    </div>
    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
    </script></div>
</div>
</div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
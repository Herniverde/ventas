

<?php $__env->startSection('title', 'Bienvenido a App Shop'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>
<div class="header header-filter" style="background-image: url('/img/bgMain1.jpg');">
</div>

<div class="main main-raised">
    <div class="container">        

        <div class="section text-center">
            <h2 class="title">Actualizar producto</h2>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
				
                    <div class="col-sm-6">
					<th class="col-md-2 text-center">Nombre</th>
                        <div class="input-group">
						 
                            <span class="input-group-addon">
							
                            <i class="material-icons">note_add</i></span>
                            <input type="text" placeholder="Nombre del producto" name="name" 
                                   class="form-control" value="<?php echo e(old('name', $product->name)); ?>">
                        </div>
                    </div>

                     <div class="col-sm-6">
					 <th class="col-md-2 text-center">Precio</th>
                        <div class="input-group">
                            <span class="input-group-addon">
                            <i class="material-icons">attach_money</i></span>
                            <input type="number" min="0" step="0.01" placeholder="Precio del producto" name="price" class="form-control" value="<?php echo e(old('price', $product->price )); ?>">
                        </div>                        
                    </div>
                </div>

                
				
				
                    <div class="row">
                      <div class="col-sm-6">
					  <th class="col-md-2 text-center">Descripción corta</th>
                        <div class="input-group">
                         <span class="input-group-addon">
                                <i class="material-icons">description</i></span>                       
                            <input type="text" placeholder="Descripción corta" name="description" class="form-control" value="<?php echo e(old('description', $product->description)); ?>">
                          </div>
                        </div>  
			<div class="col-sm-6">
			<th class="col-md-2 text-center">Descuento</th>
                        <div class="input-group">
                            <span class="input-group-addon">
                            <i class="material-icons">attach_money</i></span>
                            <input type="number" min="0" step="0.01" placeholder="Descuento" name="discount" class="form-control" value="<?php echo e(old('discount', $product->discount )); ?>">
                        </div>                        
                    </div>
				  </div>   
                  
				<div class="row">
					   <div class="col-sm-6">
                        <th class="col-md-2 text-center">Categoria</th>         
                               <select class="form-control" name="category_id">
                                   <option value="0">General</option>
                                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($category->id); ?>" <?php if($category->id == old('category_id', $product->category_id)): ?> selected <?php endif; ?>>
                                     <?php echo e($category->name); ?>

                                   </option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>                               
                                      </div>               
                </div>
                   
                

               <th class="col-md-2 text-center">Descripción larga</th>

                 <div class="input-group">
				 
                     <span class="input-group-addon">
                            <i class="material-icons">reorder</i></span>   
                <textarea class="form-control" placeholder="Descripción larga del producto" rows="5" name="long_description"><?php echo e(old('long_description', $product->long_description)); ?></textarea>
                </div>
                
                <button class="btn btn-primary">Guardar cambios</button>
                <a href="<?php echo e(url('/admin/products')); ?>" class="btn btn-default">Cancelar</a>

            </form>

        </div>


       
    </div>

</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
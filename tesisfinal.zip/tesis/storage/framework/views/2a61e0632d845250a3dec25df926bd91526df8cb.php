<?php $__env->startSection('title', 'Historico pedidos'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url(<?php echo e(url('/img/bg1.jpg')); ?>) ">
</div>

<div class="main main-raised">
    <div class="container">        
 <div class="id">
                    <h3 class="title"><?php echo e($carts->id); ?></h3>                   
                </div>
        <div class="section text-center">
            <h2 class="title">Historico pedidos</h2>
            
                <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>
                    
                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">
                                    <li class="active">                                   
                                      <a href="<?php echo e(url('/home')); ?>" role="tab" data-toggle="tab">
                                            <i class="material-icons">dashboard</i>
                                            HISTORICO DE PEDIDOS
                                        </a>
                                    </li>
                            
                                                                      
                            
                            
                            
                        </ul>
                    </div>
                            <div class="col-sm-4">                                    
                                                                    
                                   
                            </div>
                    </div>
                    
                    <hr>
                        
                      <p>has realizado <?php echo e(auth()->user()->cart->count()); ?> pedidos </p>
                            
                         <table class="table">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center">Nombre</th>                               
                                <th class="text-right">Precio</th>
                                <th class='text-center'>Cantidad</th>
                                <th class="text-center">Subtotal</th>
                                <th class="text-right">Acciones</th>
                            </tr>
                        </thead>
                        
						
						<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						<td><?php echo e($row['id']); ?></td>
						
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                    </table>
                        
                 


        </div>


       
    </div>

</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
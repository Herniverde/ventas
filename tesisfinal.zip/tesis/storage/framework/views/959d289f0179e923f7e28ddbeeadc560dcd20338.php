<footer class="footer">
    <div class="container">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="/contact">
                        ¿Necesitas ayuda con un pedido?
                    </a>
                </li>
                <li>
                    <a href="/location">
                       Nuestras ubicaciones
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('https://granjanonoudla.blogspot.com/')); ?>" target="_blank">
                       Blog
                    </a>
                </li>
                
            </ul>
        </nav>
        <div class="copyright pull-right">
            
        </div>
    </div>
</footer>


<?php $__env->startSection('title', 'Historico pedidos'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url(<?php echo e(url('/img/bg1.jpg')); ?>) ">
</div>

<div class="main main-raised">
    <div class="container">        

        <div class="section text-center">
            <h2 class="title">Historico pedidos</h2>
            
                <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>
                    
                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">
                                    <li class="active">                                   
                                      <a href="<?php echo e(url('/home')); ?>" role="tab" data-toggle="tab">
                                            <i class="material-icons">dashboard</i>
                                            Historico de pedidos
                                        </a>
                                    </li>
                            
                           
                            
                        </ul>
                    </div>
                            
                    </div>
                    
                    <hr>
                        
                     
                            
                         <table class="table">
                        <thead>
                            <tr>
							
							
                                <th class="text-center">Número de pedido</th> 
                                <th class="text-center">Email</th>
								<th class="text-center">User_id</th> 								
                                <th class="text-center">telefono cliente</th> 	
								
                                <th class='text-center'>cantidad de productos pedidos</th>
                               <th class="text-center">lista de productos</th>
							   
                            </tr>
							
                        </thead>
						 <tbody>
                       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					          
						<tr>
							<td><?php echo e($user->cart_id); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td><?php echo e($user->user_id); ?></td>
							<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->quantity); ?></td>
							<td><?php echo e($user->name); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 </tbody>
						</table>
                    
						                                
                    
									<a href="<?php echo e(url('/')); ?>" >
                                          <?php echo e(csrf_field()); ?>                   
											<button class="btn btn-primary btn-around">
                                        Regresar
										</button>
                                  
								  </a>
                                                                    
                       
        </div>


       
    </div>

</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<footer class="footer">
    <div class="container">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="/contact">
                        ¿Necesitas ayuda con un pedido?
                    </a>
                </li>
                <li>
                    <a href="/location">
                       Nuestras ubicaciones
                    </a>
                </li>
                <li>
                    <a href="/">
                       Blog
                    </a>
                </li>
                
            </ul>
        </nav>
        <div class="copyright pull-right">
            
        </div>
    </div>
</footer>
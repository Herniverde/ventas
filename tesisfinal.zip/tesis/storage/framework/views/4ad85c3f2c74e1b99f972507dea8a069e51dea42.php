<?php $__env->startSection('title', 'Ubicaciones'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url(<?php echo e(url('/img/bgMain1.jpg')); ?>) ">
</div>

<div class="main main-raised">
    <div class="container">

        <div class="section text-center">
            <h2 class="title">Ubicaciones</h2>
              <h3 class="title">Te esperamos los lunes, martes y miércoles de 11:00  a 15:00 en los siguientes puntos de atención: </h3>
                <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">




                        </ul>
                    </div>

                    </div>

                  



                         <table class="table">
                        <thead>
                            <tr>


                                <th class="text-center">Nombre</th>
                                <th class="text-center">Horario de atencion</th>
                                <th class='text-center'>Dirección</th>

                            </tr>

                        </thead>
						 <tbody>


						<tr>

                <td>Queri </td>
                <td>Lunes, entrada principal, bloque 1</td>
                <td><a href="<?php echo e(url('https://goo.gl/maps/dFS98jZCr962')); ?>" target="_blank">
                                            <?php echo e(csrf_field()); ?>

                        <button class="btn btn-primary btn-around">
                                          Mapa
                      </button>

                    </a> </td>
	</tr>	<tr>
            	<td>UdlaPark </td>
							<td>Martes, en el Patio Amazónico</td>
							<td><a href="<?php echo e(url('https://goo.gl/maps/hCp68W6ci3t')); ?>" target="_blank">
                                          <?php echo e(csrf_field()); ?>

											<button class="btn btn-primary btn-around">
                                        Mapa
										</button>

								  </a> </td>
							</tr>
							<tr>
							<td>Granados </td>
							<td>Miércoles, junto a La Corteza</td>
							<td><a href="<?php echo e(url('https://goo.gl/maps/iimZsy8n5kt')); ?>" target="_blank">
                                          <?php echo e(csrf_field()); ?>

											<button class="btn btn-primary btn-around">
                                        Mapa
										</button>

								  </a> </td>

							</tr>

            </tbody>

 </div>
         </table>
		 
		 
		   <div class="section text-center">
            
              <h3 class="title">Y los días jueves de 10:30 a 14:30 en el siguiente punto de atención:</h3>
                <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">




                        </ul>
                    </div>

                    </div>


</div>

                         <table class="table">
                        <thead>
                            <tr>


                                <th class="text-center">Nombre</th>
                                <th class="text-center">Horario de atencion</th>
                                <th class='text-center'>Dirección</th>

                            </tr>

                        </thead>
						 <tbody>


						

               
							<tr>
							<td>Colón</td>
							<td>Jueves, patio central</td>
							<td><a href="<?php echo e(url('https://goo.gl/maps/UhPwY9FBbsC2')); ?>" target="_blank">
                                          <?php echo e(csrf_field()); ?>

											<button class="btn btn-primary btn-around">
                                        Mapa
										</button>

								  </a> </td>
							</tr>

            </tbody>


         </table>
		
		   <div class="section text-center">
              <h3 class="title">Te esperamos los lunes, martes y miércoles de 11:00  a 15:00 en los siguientes puntos de atención: </h3>
                <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-sm-8">
                        <ul class="nav nav-pills nav-pills-primary" role="tablist">




                        </ul>
                    </div>

                    </div>

                   



                         <table class="table">
                        <thead>
                            <tr>


                                <th class="text-center">Nombre</th>
                                <th class="text-center">Horario de atencion</th>
                                <th class='text-center'>Dirección</th>

                            </tr>

                        </thead>
						 <tbody>


						<tr>

                <td>Oficina de la Granja </td>
                <td>Sede Queri, frente al bloque 5</td>
                <td><a href="<?php echo e(url('https://goo.gl/maps/dFS98jZCr962')); ?>" target="_blank">
                                            <?php echo e(csrf_field()); ?>

                        <button class="btn btn-primary btn-around">
                                          Mapa
                      </button>

                    </a> </td>
	</tr>	
			
            </tbody>

         </table>
		 
    </div>


</div>
</div>
</div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
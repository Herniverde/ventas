
<?php $__env->startComponent('mail::message'); ?>
# New message from <?php echo e($name); ?>


<?php echo e($text); ?>


<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class OrdersController extends Controller {

public function index(){

 

$users = DB::select('SELECT * FROM `cart_details`, `carts`, `users`,`products`  WHERE cart_id=carts.id and carts.user_id=users.id and cart_details.product_id= products.id order by email');
return view('orders.show',['users'=>$users]);

}

}